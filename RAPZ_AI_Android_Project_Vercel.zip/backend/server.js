import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

app.post("/solve", async (req, res) => {
  try {
    const question = String(req.body?.question ?? "").trim();
    if (!question) return res.status(400).json({ error: "Teks soal kosong." });
    if (question.length > 12000) return res.status(413).json({ error: "Teks soal terlalu panjang." });

    const apiKey = process.env.AI_API_KEY;
    if (!apiKey) return res.status(500).json({ error: "AI_API_KEY belum disetel di server." });

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: "Kamu adalah RAPZ AI, tutor yang membantu memahami tugas sekolah. Jawab dalam Bahasa Indonesia. Berikan jawaban yang tepat, langkah pengerjaan singkat, dan penjelasan yang mudah dipahami. Jika teks soal tidak lengkap atau ambigu, jelaskan bagian yang perlu diperjelas. Jangan mengarang.",
        input: question,
        max_output_tokens: 1200
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data.error?.message ?? "Penyedia AI mengembalikan error." });
    }
    const answer = data.output_text ??
      (data.output ?? []).flatMap(item => item.content ?? [])
        .filter(part => part.type === "output_text")
        .map(part => part.text).join("\n");
    return res.json({ answer: answer || "AI tidak menghasilkan teks jawaban." });
  } catch (error) {
    return res.status(500).json({ error: "Kesalahan server: " + error.message });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`RAPZ AI backend listening on ${port}`));
