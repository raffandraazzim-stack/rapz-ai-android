package com.rapzai.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 7001
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "RAPZ AI"
            textSize = 30f
        })
        layout.addView(TextView(this).apply {
            text = "Asisten AI melayang untuk membaca soal dari screenshot dengan izin pengguna."
            textSize = 16f
            setPadding(0, 12, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "1. Aktifkan izin tampil di atas aplikasi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else toast("Izin overlay sudah aktif.")
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Mulai panel melayang"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    toast("Aktifkan izin overlay terlebih dahulu.")
                    return@setOnClickListener
                }
                startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
            }
        })
        layout.addView(Button(this).apply {
            text = "Hentikan panel"
            setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }
        })
        layout.addView(TextView(this).apply {
            text = "\nPrivasi: Android akan meminta persetujuan screen capture. Indikator sistem tidak disembunyikan."
            textSize = 13f
        })
        setContentView(layout)
    }

    @Deprecated("Activity result API kept minimal for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, OverlayService::class.java).apply {
                    putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(OverlayService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
                else startService(service)
                toast("RAPZ AI aktif. Buka aplikasi berisi soal.")
            } else toast("Izin screen capture tidak diberikan.")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
