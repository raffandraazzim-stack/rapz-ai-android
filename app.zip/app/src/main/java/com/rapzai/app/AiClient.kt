package com.rapzai.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

object AiClient {
    private val executor = Executors.newSingleThreadExecutor()

    fun solve(question: String, callback: (String) -> Unit) {
        executor.execute {
            val result = try {
                val url = URL(Config.AI_BACKEND_URL)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("question", question).toString()
                conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                if (conn.responseCode in 200..299) json.optString("answer", "AI tidak mengembalikan jawaban.")
                else "Backend error ${conn.responseCode}: ${json.optString("error", response)}"
            } catch (e: Exception) {
                "Tidak dapat terhubung ke AI. Periksa URL backend dan koneksi internet. (${e.message})"
            }
            callback(result)
        }
    }
}
