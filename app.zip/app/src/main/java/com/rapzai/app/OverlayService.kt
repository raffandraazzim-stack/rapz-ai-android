package com.rapzai.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class OverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "rapz_ai_capture"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var windowManager: WindowManager
    private var panel: android.view.View? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var answerView: TextView? = null
    private val busy = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 1

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val resultData = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            if (resultData == null || resultCode != Activity.RESULT_OK) {
                stopSelf(); return START_NOT_STICKY
            }
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post { stopSelf() }
                }
            }, mainHandler)
            showPanel()
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun showPanel() {
        if (panel != null || !android.provider.Settings.canDrawOverlays(this)) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xEE17152B.toInt())
        }
        val header = TextView(this).apply {
            text = "✦ RAPZ AI  •  FLOATING"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        answerView = TextView(this).apply {
            text = "Siap membaca soal. Posisikan soal di layar lalu tekan Ambil & Jawab."
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 12)
        }
        val capture = Button(this).apply {
            text = "Ambil & Jawab"
            setOnClickListener { captureAndRead() }
        }
        val close = Button(this).apply {
            text = "Hentikan RAPZ AI"
            setOnClickListener { stopSelf() }
        }
        root.addView(header); root.addView(answerView)
        root.addView(capture); root.addView(close)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.82f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 90 }
        panel = root
        windowManager.addView(root, params)
    }

    private fun captureAndRead() {
        if (!busy.compareAndSet(false, true)) return
        answerView?.text = "Mengambil screenshot…"
        try {
            imageReader?.close()
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * screenWidth
                    val bitmap = android.graphics.Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride, screenHeight,
                        android.graphics.Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)
                    val cropped = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
                    bitmap.recycle()
                    image.close()
                    virtualDisplay?.release()
                    virtualDisplay = null
                    runOcr(cropped)
                } catch (e: Exception) {
                    image.close()
                    fail("Gagal membaca screenshot: ${e.message}")
                }
            }, mainHandler)
            virtualDisplay?.release()
            virtualDisplay = projection?.createVirtualDisplay(
                "RAPZ-AI-Capture", screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, mainHandler
            )
            mainHandler.postDelayed({
                if (virtualDisplay != null) {
                    virtualDisplay?.release(); virtualDisplay = null
                    fail("Screenshot tidak berhasil. Coba lagi.")
                }
            }, 3500)
        } catch (e: Exception) {
            fail("Capture gagal: ${e.message}")
        }
    }

    private fun runOcr(bitmap: android.graphics.Bitmap) {
        answerView?.text = "Membaca teks soal…"
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                bitmap.recycle()
                val question = result.text.trim()
                recognizer.close()
                if (question.isBlank()) { fail("Teks tidak terdeteksi. Coba screenshot yang lebih jelas."); return@addOnSuccessListener }
                answerView?.text = "Soal terbaca. Meminta jawaban AI…"
                AiClient.solve(question) { response ->
                    mainHandler.post {
                        answerView?.text = response
                        busy.set(false)
                    }
                }
            }
            .addOnFailureListener { e ->
                bitmap.recycle(); recognizer.close()
                fail("OCR gagal: ${e.message}")
            }
    }

    private fun fail(message: String) {
        mainHandler.post { answerView?.text = message; busy.set(false) }
    }

    override fun onDestroy() {
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "RAPZ AI screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("RAPZ AI aktif")
        .setContentText("Screen capture aktif dengan persetujuan pengguna. Tekan untuk kembali ke aplikasi.")
        .setSmallIcon(android.R.drawable.ic_menu_view)
        .setOngoing(true)
        .build()
}
