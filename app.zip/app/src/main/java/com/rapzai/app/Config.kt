package com.rapzai.app

object Config {
    // Ganti dengan endpoint HTTPS backend milikmu.
    // Jangan masukkan API key AI ke aplikasi Android.
    const val AI_BACKEND_URL = "https://rapz-ai-backend.vercel.app/solve"
}
